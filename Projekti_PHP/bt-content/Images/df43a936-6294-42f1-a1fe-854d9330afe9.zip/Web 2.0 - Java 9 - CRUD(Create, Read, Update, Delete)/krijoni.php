<?php
// Përfshije fajllin e konfigurimit.
require_once "konfigurimi.php";
 
// Definimi i variablave dhe inicializimi me vlera bosh.
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Procesimi i dhënave të formës kur forma dërgohet (submitted).
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
    // Validoni emrin.
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Ju lutemi shkruani një emër.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $name_err = "Ju lutemi shkruani një emër të vlefshëm.";
    } else{
        $name = $input_name;
    }
    
    // Validoni adresën.
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Ju lutemi shkruani një adresë.";     
    } else{
        $address = $input_address;
    }
    
    // Validoni pagën.
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Ju lutemi shkruani shumën e pagës.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Ju lutemi shkruani një vlerë të plotë pozitive.";
    } else{
        $salary = $input_salary;
    }
    
    // Kontrolloni gabimet e përdoruesit para futjes në databazë.
    if(empty($name_err) && empty($address_err) && empty($salary_err)){
        
        $sql = "INSERT INTO tblpuntoret (name, address, salary) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
       
			// Bind (vendos/lidh) variablat në deklaratën e përgatitur si parametra.
            mysqli_stmt_bind_param($stmt, "sss", $param_name, $param_address, $param_salary);
            
            // Vendosni parametrat.
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            
            // Përpjekje për të ekzekutuar deklaratën e përgatitur.
            if(mysqli_stmt_execute($stmt)){
           
				// Regjistrimi u krye me sukses. Redirektoheni tek faqja index.php.
                header("location: index.php");
                exit();
            } else{
                echo "Dicka shkoi keq. Ju lutem provoni përsëri më vonë.";
            }
        }
         
        // Mbyll deklaratën.
        mysqli_stmt_close($stmt);
    }
    
    // Mbyll koneksionin (lidhjen).
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Krijimi</title>
	
	<!-- Definimi i bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    
	<!-- Përdorimi i CSS-->
	<style type="text/css">
        .stilizimi{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>

<!-- Paraqitja e përmbajtjes (emri, adresa, paga etj.) -->
<!-- Për rregullim të përmbajtjes shfrytëzohet bootstrap -->
<body>
    <div class="stilizimi">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Krijo regjistrimin</h2>
                    </div>
                    <p>Ju lutemi plotësoni këtë formular dhe paraqitni për të shtuar  punonjës në bazën e të dhënave.</p>
                   
				   <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">                   
					   <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Emri</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                            <span class="help-block"><?php echo $name_err;?></span>
                        </div>
						
                        <div class="form-group <?php echo (!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>Adresa</label>
                            <textarea name="address" class="form-control"><?php echo $address; ?></textarea>
                            <span class="help-block"><?php echo $address_err;?></span>
                        </div>
						
                        <div class="form-group <?php echo (!empty($salary_err)) ? 'has-error' : ''; ?>">
                            <label>Paga</label>
                            <input type="text" name="salary" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $salary_err;?></span>
                        </div>
						
                        <input type="submit" class="btn btn-primary" value="Dergo">
                        <a href="index.php" class="btn btn-default">Anuloje</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>