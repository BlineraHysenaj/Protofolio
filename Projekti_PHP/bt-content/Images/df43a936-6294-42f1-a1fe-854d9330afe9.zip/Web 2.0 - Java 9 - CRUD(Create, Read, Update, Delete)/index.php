<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Faqja kryesore</title>
	
	<!-- Definimi i bootstrap dhe jquery-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    
	 <!-- Përdorimi i CSS-->
	<style type="text/css">
        .stilizimi{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
	
	<!-- Krijimi i skriptes -->
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>

<!-- Paraqitja e përmbajtjes së faqes kryesore index.php -->
<!-- Për rregullim të përmbajtjes shfrytëzohet bootstrap -->
<body>
    <div class="stilizimi">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Detajet e puntorit</h2>
                        <a href="krijoni.php" class="btn btn-success pull-right">Shto punonjës të ri</a>
                    </div>
                    <?php
                    // Përfshije fajllin e konfigurimit.
                    require_once "konfigurimi.php";
                    
                    // Përpjekje për ekzutuar query e zgjedhur.
                    $sql = "SELECT * FROM tblpuntoret";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0)
						{
							// Paraqitja e tabelës me të dhënat. 
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>ID</th>";
                                        echo "<th>Emri</th>";
                                        echo "<th>Adresa</th>";
                                        echo "<th>Paga</th>";
                                        echo "<th>Veprimi</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['name'] . "</td>";
                                        echo "<td>" . $row['address'] . "</td>";
                                        echo "<td>" . $row['salary'] . "</td>";
                                        echo "<td>";
                                            echo "<a href='lexo.php?id=". $row['id'] ."' title='Shiko të dhënat' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='perditeso.php?id=". $row['id'] ."' title='Përditeso/Ndrysho të dhënat ' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                            echo "<a href='fshije.php?id=". $row['id'] ."' title='Fshijë të dhënat' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Vendosni rezultatin.
                            mysqli_free_result($result);
                        } else{ // Paraqite mesazhin.
                            echo "<p class='lead'><em>Nuk u gjetën shënime.</em></p>";
                        }
						// Paraqite gabimin.
                    } else{
                        echo "GABIM: Nuk mundi të ekzekutonte $sql. " . mysqli_error($link);
                    }
                    // Mbyllet lidhja.
                    mysqli_close($link);
                    ?>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>





<!-- Në vazhdim poashtu keni edhe referencat të ndryshme të punimit:
https://www.tutorialrepublic.com/php-tutorial/php-mysql-crud-application.php
https://www.codeofaninja.com/2011/12/php-and-mysql-crud-tutorial.html
https://www.tutorialspoint.com/mysql/mysql-quick-guide.htm
http://blog.chapagain.com.np/very-simple-add-edit-delete-view-in-php-mysql/
https://www.javatpoint.com/mysql-tutorial
-->