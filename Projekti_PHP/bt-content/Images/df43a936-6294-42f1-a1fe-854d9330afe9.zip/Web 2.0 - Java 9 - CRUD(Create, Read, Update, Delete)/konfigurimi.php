<?php
// Kredencialet e DB.
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'ushtrimecrud');
 
// Përpjekje për t'u lidhur me bazën e të dhënave MySQL. 
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Kontrolloni lidhjen.
if($link === false){
    die("Gabim. " . mysqli_connect_error());
}
?>