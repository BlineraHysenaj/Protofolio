<?php
// Përfshije fajllin e konfigurimit.
require_once "konfigurimi.php";
 
// Definimi i variablave dhe inicializimi me vlera bosh.
$name = $address = $salary = "";
$name_err = $address_err = $salary_err = "";
 
// Procesimi i dhënave të formës kur forma është derguar (submitted).
if(isset($_POST["id"]) && !empty($_POST["id"])){
	// Merrni vlerën e fshehur të hyrjes.
    $id = $_POST["id"];
    
    // Validoni emrin.
    $input_name = trim($_POST["name"]);
    if(empty($input_name)){
        $name_err = "Ju lutem jepni emrin tuaj.";
    } elseif(!filter_var($input_name, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $name_err = "Ju lutemi shkruani një emër të vlefshëm.";
    } else{
        $name = $input_name;
    }
    
    // Validoni adresën.
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Ju lutem jepni adresën tuaj.";     
    } else{
        $address = $input_address;
    }
    
    // Validoni pagën.
    $input_salary = trim($_POST["salary"]);
    if(empty($input_salary)){
        $salary_err = "Ju lutemi shkruani shumën e pagës.";     
    } elseif(!ctype_digit($input_salary)){
        $salary_err = "Ju lutemi shkruani një vlerë të plotë pozitive.";
    } else{
        $salary = $input_salary;
    }
    
	// Kontrolloni gabimet e përdoruesit përpara insertimit në databazë.
    if(empty($name_err) && empty($address_err) && empty($salary_err)){

		// Përgatitni një deklaratë të përditësimit (update).
        $sql = "UPDATE tblpuntoret SET name=?, address=?, salary=? WHERE id=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
			
			//  Bind (vendos/lidh) variablat në deklaratën e përgatitur si parametra.
            mysqli_stmt_bind_param($stmt, "sssi", $param_name, $param_address, $param_salary, $param_id);
            
            // Vendos parametrat.
            $param_name = $name;
            $param_address = $address;
            $param_salary = $salary;
            $param_id = $id;
            
            // Përpjekje për të ekzekutuar deklaratën e përgatitur.
            if(mysqli_stmt_execute($stmt)){
                // Regjistrimet u përditësuan(update) me sukses.
				// Redirektohuni në faqen e index.php
                header("location: index.php");
                exit();
            } else{
                echo "Dicka shkoi keq. Ju lutem provoni përsëri më vonë.";
            }
        }
         
        // Mbyll deklaratën.
        mysqli_stmt_close($stmt);
    }
    
    // Mbyll lidhjen.
    mysqli_close($link);
} else{
    // Kontrolloni ekzistencën e parametrit id përpara se të përpunoni më tej.
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Merr parametrin URL.
        $id =  trim($_GET["id"]);
        
        // Përgaditni një deklaratë të zgjedhur.
        $sql = "SELECT * FROM tblpuntoret WHERE id = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind (vendos/lidh)variablat në deklaratën e përgatitur si parametra.
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Vendosni parametrat.
            $param_id = $id;
            
            // Përpjekje për të ekzekutuar deklaratën e përgatitur.
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
					
					/* Merrni rreshtin e rezultatit si një array shoqërues. 
					Meqë grupi i rezultateve përmban vetëm një rresht,
					ne nuk duhet të përdorim While loop. */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Marrja e vlerës individuale të fushës.
                    $name = $row["name"];
                    $address = $row["address"];
                    $salary = $row["salary"];
                } else{
                    // URL-ja nuk përmban ID të vlefshëm. 
					// Redirektohuni në faqen e gabimit.
                    header("location: gabimet.php");
                    exit();
                }
                
            } else{
                echo "Oops! Dicka shkoi keq. Ju lutem provoni përsëri më vonë.";
            }
        }
        
        // Mbyll deklaratën.
        mysqli_stmt_close($stmt);
        
        // Mbyll lidhjën.
        mysqli_close($link);
    }  else{
        // URL-ja nuk përmban parametër id. Redirektohuni në faqen e gabimit.
        header("location: gabimet.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Përditësimi i regjistrimeve</title>
	
	<!-- Definimi i bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
  
  <!-- Përdorimi i CSS-->
	<style type="text/css">
        .stilizimi{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
<!-- Përditesimi i të dhënave -->
    <div class="stilizimi">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Përditësimi i regjistrimeve</h2>
                    </div>
                    <p>Ju lutemi ndryshoni vlerat e dhëna dhe dergoni për të përditësuar regjistrimin.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                            <label>Emri</label>
                            <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                            <span class="help-block"><?php echo $name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>Adresa</label>
                            <textarea name="address" class="form-control"><?php echo $address; ?></textarea>
                            <span class="help-block"><?php echo $address_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($salary_err)) ? 'has-error' : ''; ?>">
                            <label>Paga</label>
                            <input type="text" name="salary" class="form-control" value="<?php echo $salary; ?>">
                            <span class="help-block"><?php echo $salary_err;?></span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Përditëso të dhënat.">
                        <a href="index.php" class="btn btn-default">Anuloje tani.</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>