<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gabimet</title>
	
	<!-- Definimi i bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
   
   <!-- Përdorimi i CSS-->
   <style type="text/css">
        .stilizimi{
            width: 750px;
            margin: 0 auto;
        }
    </style>
</head>
<!-- Paraqitja e gabimeve, kur diqka nuk është në rregull-->
<!-- Shfrytëzimi i bootstrap -->
<body>
    <div class="stilizimi">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>Kërkesë e pavlefshme</h1>
                    </div>
                    <div class="alert alert-danger fade in">
                        <p>Na vjen keq, ke bërë një kërkesë të pavlefshme. ju lutem <a href="index.php" class="alert-link">kthehuni</a> dhe provoni perseri.</p>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>