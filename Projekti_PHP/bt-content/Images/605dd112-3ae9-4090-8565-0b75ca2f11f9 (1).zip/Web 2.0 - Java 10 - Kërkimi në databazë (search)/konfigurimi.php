<?php
// Lidhja.
$link = mysqli_connect("localhost", "root", "", "kerkimidb");
 
// Shikohet lidhja.
if($link === false){
    die("Gabim nuk mund të kryhet lidhja! " . mysqli_connect_error());
}
 
if(isset($_REQUEST["term"])){
    // Përgatitni një deklaratë të zgjedhur.
    $sql = "SELECT * FROM vendetdb WHERE name LIKE ?";
    
    if($stmt = mysqli_prepare($link, $sql)){
        // Bind vendos/lidh variablat në deklaratën e përgatitur si parametra.
        mysqli_stmt_bind_param($stmt, "s", $param_term);
        
        // Vendos parametrat.
        $param_term = $_REQUEST["term"] . '%';
        
        // Përpjekje për të ekzekutuar deklaratën e përgatitur.
        if(mysqli_stmt_execute($stmt)){
            $rezultati = mysqli_stmt_get_result($stmt);
            
			// Kontrolloni numrin e rreshtave në setin e rezultateve.
            if(mysqli_num_rows($rezultati) > 0){

				// Merrni rreshtat e rezultateve si një array shoqërues.
                while($row = mysqli_fetch_array($rezultati, MYSQLI_ASSOC)){
                    echo "<p>" . $row["name"] . "</p>";
                }
            } else{
                echo "<p>Nuk u gjetën rezultate</p>";
            }
        } else{
            echo "Gabim: Nuk mundi të ekzekutonte $sql. " . mysqli_error($link);
        }
    }
     
    // Mbyll deklaratën.
    mysqli_stmt_close($stmt);
}
 
// Mbyll lidhjen.
mysqli_close($link);
?>