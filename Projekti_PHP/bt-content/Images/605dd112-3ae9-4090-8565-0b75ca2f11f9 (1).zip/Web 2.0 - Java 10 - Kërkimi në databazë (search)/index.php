<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>PHP dhe MySQL kërkimi në databazë</title>
<style type="text/css">
 /* Stilizimi i rezultateve të elementeve */	
	.rezultati{
        position: absolute;        
        z-index: 999;
        top: 100%;
        left: 0;
    }
    .rezultati p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .rezultati p:hover{
        background: #f2f2f2;
    }
		
    /* Formatimi i kutis se kërkimit */
    .kutia-kerkimit{
        width: 300px;
        position: relative;
        display: inline-block;
        font-size: 14px;
    }
    .kutia-kerkimit input[type="text"]{
        height: 32px;
        padding: 5px 10px;
        border: 1px solid #CCCCCC;
        font-size: 14px;
    }
 
    .kutia-kerkimit input[type="text"], .rezultati{
        width: 100%;
        box-sizing: border-box;
    }
</style>



<!-- Sa herë që ndryshohet përmbajtja e inputit në kërkim ose 
ndodhin ngjarjet e tastierës në inputin e kërkimit, kodi jQuery
 dërgoi një kërkesë të Ajax në fajllin 
"konfigurimi.php" i cili merr rekordet nga tabela e vendeve 
që lidhen me termin e kontrolluar. Këto regjistrime më vonë do të futen
brenda një <div> nga jQuery dhe do të shfaqen të shfletuesi. -->

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.kutia-kerkimit input[type="text"]').on("keyup input", function(){
        /* Merrni vlerën e hyrjes në ndryshim. */
        var vleraInputit = $(this).val();
        var rezultatiDropdown = $(this).siblings(".rezultati");
        if(vleraInputit.length){
            $.get("konfigurimi.php", {term: vleraInputit}).done(function(data){           
				// Shfaqni të dhënat e kthyera në shfletues.
                rezultatiDropdown.html(data);
            });
        } else{
            rezultatiDropdown.empty();
        }
    });    
    // Vendosni vlerën e hyrjes së kërkimit në klikimin e elementit të rezultatit.
    $(document).on("click", ".rezultati p", function(){
        $(this).parents(".kutia-kerkimit").find('input[type="text"]').val($(this).text());
        $(this).parent(".rezultati").empty();
    });
});
</script>
</head>
<body>
    <div class="kutia-kerkimit">
        <input type="text" autocomplete="off" placeholder="Kerko vende ..." />
        <div class="rezultati"></div>
    </div>
</body>
</html>



<!-- Referencat:
http://php.net/manual/en/
https://www.tutorialrepublic.com/php-tutorial/php-mysql-ajax-live-search.php
https://www.javatpoint.com/mysql-tutorial
-->