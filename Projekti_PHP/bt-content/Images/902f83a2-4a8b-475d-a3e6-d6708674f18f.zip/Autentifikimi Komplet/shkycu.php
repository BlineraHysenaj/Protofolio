<?php
// Inicializoni sesionin.
session_start();
 
 
// Hiqni (Unset) të gjitha variablat e sesionit.
$_SESSION = array();
 
// Shkatërroni sesionin.
// Shkatërron të gjitha të dhënat e regjistruara në një sesion.
session_destroy();
 
// Redirektoni në faqen e identifikimit.
header("location: kycu.php");
exit;
?>