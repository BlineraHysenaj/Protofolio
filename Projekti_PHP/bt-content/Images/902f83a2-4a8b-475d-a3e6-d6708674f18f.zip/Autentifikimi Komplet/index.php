<?php
// Nj� sesion �sht� nj� m�nyr� p�r t� ruajtur informacionet (n� variabla) 
// q� do t� p�rdoren n� shum� faqe, ndryshe 
// nga nj� cookie, informacioni nuk ruhet n� kompjuterin e p�rdoruesve.

// Inicializimi i sesionit.
session_start();
 
// Kontrolloni n�se p�rdoruesi �sht� i kycur, 
// n�se jo at�her� redirekto tek kycja/identifikimi (kycu.php).
// Funksioni isset () zakonisht p�rdoret p�r t� kontrolluar 
// n�se nj� variab�l �sht� vendosur ose jo.
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: kycu.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html>
<head>
<!-- Specifikimi i setit t� karaktereve -->
    <meta charset="UTF-8">
	<!-- Titulli i faqes -->
    <title>P&euml;rsh&euml;ndetje !</title>
	
<!-- P�rdorimi i bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.0/css/bootstrap.min.css">
    
<!-- P�rdorimi i CSS -->
	<style type="text/css">	
        body{ 
			text-align: center; 
			font: 14px sans-serif; 			
		}
    </style>
</head>
<body>

<!-- Paraqitja e faqes ku p�rdoruesi �sht� i kycur -->
<!-- P�rdorimi i klas�s  page-header t� bootstrap p�r paraqitje faqes header n� 
  faqen  t� cilen p�rdoruesi  �sht� kycur -->
    <div class="page-header">
	
	<!-- Konvertimi i element�ve t� paracaktuar "<" (m� i vog�l se) dhe ">" (m� i madh se) tek entitetet HTML  -->
        <h3>P&euml;rsh&euml;ndetje, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b> </h3>
		<br>

		<h1>Mir&euml; se vini n&euml; Gjuh&euml;t  Web dhe Teknologjit&euml;! </h1>	
		<h4>MSc. Edon Bublaku </h4> 
 <p> Kjo &euml;sht&euml; pjesa ku mund t&euml; vendosni dizajnin  kryesor (index.php).  </p>
 
    </div>

    <p>
		<!-- Krijimi i butonit p�r rivendonsje t� fjal�kalimit-->
        <a href="ndrysho-fjalekalimin.php" class="btn btn-warning">Ndryshoni fjal&euml;kalimin tani !</a>
		
		<!-- Krijimi i butonit p�r regjistrim t� llogaris�-->
        <a href="shkycu.php" class="btn btn-danger">Dilni nga llogaria juaj!</a>
    </p>
</body>
</html>





<!-- N� vazhdim poashtu keni edhe referencat t� ndryshme t� punimit:
https://gist.github.com/HoangPV/f57143e52a2b49ca9a407508d9a0c76e
https://www.tutorialrepublic.com/php-tutorial/php-mysql-login-system.php
https://tutorialzine.com/2009/10/cool-login-system-php-jquery
https://www.tutorialspoint.com/php/php_mysql_login.htm
-->